document.addEventListener('DOMContentLoaded', () => {
  // Safe element helper
  const $ = (id) => document.getElementById(id);

  // Core Inputs & Triggers
  const urlInput = $('urlInput');
  const btnPaste = $('btnPaste');
  const btnAnalyze = $('btnAnalyze');
  const btnText = btnAnalyze ? btnAnalyze.querySelector('.btn-text') : null;
  const spinnerSmall = btnAnalyze ? btnAnalyze.querySelector('.spinner-small') : null;

  // Media Preview Elements
  const mediaPreviewCard = $('mediaPreviewCard');
  const mediaThumb = $('mediaThumb');
  const mediaTitle = $('mediaTitle');
  const mediaAuthor = $('mediaAuthor');
  const mediaPlatform = $('mediaPlatform');
  const mediaDuration = $('mediaDuration');
  const multiAudioBadge = $('multiAudioBadge');
  const btnPreviewPlay = $('btnPreviewPlay');

  // Format & Quality Controls
  const pillVideoMode = $('pillVideoMode');
  const pillAudioOnlyMode = $('pillAudioOnlyMode');
  const resolutionCol = $('resolutionCol');
  const audioFormatCol = $('audioFormatCol');
  const videoQualitySelect = $('videoQualitySelect');
  const audioFormatSelect = $('audioFormatSelect');
  const audioPillsContainer = $('audioPillsContainer');
  const selectedTrackName = $('selectedTrackName');
  const embedSubsCheck = $('embedSubsCheck');
  
  // Download Button
  const btnStartDownload = $('btnStartDownload');
  const btnDownloadText = $('btnDownloadText');

  // Progress Elements
  const progressFooterCard = $('progressFooterCard');
  const progressFileText = $('progressFileText');
  const progressSize = $('progressSize');
  const progressSpeed = $('progressSpeed');
  const progressEta = $('progressEta');
  const progressPercentBadge = $('progressPercentBadge');
  const progressBarNeon = $('progressBarNeon');
  const progressActionsRow = $('progressActionsRow');

  // Post Download Action Buttons
  const btnDirectDownloadBrowser = $('btnDirectDownloadBrowser');
  const btnCopyToWindows = $('btnCopyToWindows');
  const btnOpenInExplorer = $('btnOpenInExplorer');
  const btnPlayFinished = $('btnPlayFinished');

  // Library & Sidebar Elements
  const downloadsItemsList = $('downloadsItemsList');
  const downloadsCount = $('downloadsCount');
  const btnRefreshLibrary = $('btnRefreshLibrary');
  const btnOpenDownloadsFolder = $('btnOpenDownloadsFolder');
  const btnOpenVipModal = $('btnOpenVipModal');
  const btnCloseVipModal = $('btnCloseVipModal');
  const vipModal = $('vipModal');
  const vipModalBackdrop = $('vipModalBackdrop');
  const vipNoticeBanner = $('vipNoticeBanner');
  const adminCodeInput = $('adminCodeInput');
  const btnApplyAdminCode = $('btnApplyAdminCode');
  const adminStatusMsg = $('adminStatusMsg');
  const vipStatusBadge = $('vipStatusBadge');
  const appLogo = $('appLogo');

  // Player Modal
  const playerModal = $('playerModal');
  const modalTitle = $('modalTitle');
  const modalMediaContainer = $('modalMediaContainer');
  const btnCloseModal = $('btnCloseModal');
  const modalBackdrop = $('modalBackdrop');
  const toastContainer = $('toastContainer');

  // Application State
  let currentMediaData = null;
  let selectedMode = 'video'; // 'video' | 'audio'
  let selectedAudioTrack = 'default';
  let selectedAudioLang = '';
  let activeEventSource = null;
  let lastDownloadedFilename = '';
  let isServerCloud = false;

  // --- Toast Notification System ---
  function showToast(message, type = 'info', duration = 3500) {
    if (!toastContainer) {
      console.log(`[Toast ${type}]:`, message);
      return;
    }
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    
    let icon = 'ℹ️';
    if (type === 'success') icon = '✅';
    if (type === 'error') icon = '❌';
    if (type === 'warning') icon = '⚠️';

    toast.innerHTML = `
      <span class="toast-icon">${icon}</span>
      <span class="toast-text">${message}</span>
      <button class="toast-close">✕</button>
    `;

    toast.querySelector('.toast-close').addEventListener('click', () => {
      toast.classList.add('hide');
      setTimeout(() => toast.remove(), 250);
    });

    toastContainer.appendChild(toast);
    requestAnimationFrame(() => toast.classList.add('show'));

    setTimeout(() => {
      if (toast.parentElement) {
        toast.classList.add('hide');
        setTimeout(() => toast.remove(), 250);
      }
    }, duration);
  }

  // --- VIP System & License Validation ---
  function isUserVip() {
    return Boolean(localStorage.getItem('bateyero_vip_token'));
  }

  function applyVipUI(badgeText) {
    if (vipStatusBadge) {
      vipStatusBadge.textContent = badgeText || '👑 VIP ADMIN (YAQUITO)';
      vipStatusBadge.style.color = '#fbbf24';
      vipStatusBadge.style.textShadow = '0 0 10px rgba(251, 191, 36, 0.5)';
      vipStatusBadge.classList.add('is-vip');
    }
  }

  // Initialize VIP state from storage
  if (isUserVip()) {
    applyVipUI('👑 VIP ADMIN (YAQUITO)');
  }

  // Check VIP restriction for resolution/format
  function checkVipGate(element, defaultValue) {
    const selectedOption = element.options[element.selectedIndex];
    if (selectedOption && selectedOption.dataset.vip === 'true' && !isUserVip()) {
      if (vipNoticeBanner) vipNoticeBanner.style.display = 'block';
      if (vipModal) vipModal.style.display = 'flex';
      showToast('Esta calidad requiere Bateyero VIP. Desbloquéala con tu Código de Administrador.', 'warning', 4500);
      element.value = defaultValue;
      return false;
    }
    return true;
  }

  if (videoQualitySelect) {
    videoQualitySelect.addEventListener('change', () => {
      checkVipGate(videoQualitySelect, '720');
    });
  }

  if (audioFormatSelect) {
    audioFormatSelect.addEventListener('change', () => {
      checkVipGate(audioFormatSelect, 'mp3_192');
    });
  }

  // Open/Close VIP Modal
  if (btnOpenVipModal) {
    btnOpenVipModal.addEventListener('click', () => {
      if (vipNoticeBanner) vipNoticeBanner.style.display = 'none';
      if (vipModal) vipModal.style.display = 'flex';
      if (adminCodeInput) adminCodeInput.focus();
    });
  }

  if (btnCloseVipModal) {
    btnCloseVipModal.addEventListener('click', () => {
      if (vipModal) vipModal.style.display = 'none';
    });
  }

  if (vipModalBackdrop) {
    vipModalBackdrop.addEventListener('click', () => {
      if (vipModal) vipModal.style.display = 'none';
    });
  }

  // Verify Master Admin Code with Backend Cryptographic Engine
  if (btnApplyAdminCode && adminCodeInput) {
    btnApplyAdminCode.addEventListener('click', async () => {
      const code = adminCodeInput.value.trim().toUpperCase();
      if (!code) {
        setAdminMsg('Por favor ingresa tu código de acceso.', '#ef4444');
        return;
      }

      btnApplyAdminCode.disabled = true;
      btnApplyAdminCode.textContent = 'Verificando...';

      try {
        const res = await fetch('/api/verify-license', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ key: code }),
        });

        const data = await res.json();
        if (data.success) {
          localStorage.setItem('bateyero_vip_token', data.token);
          applyVipUI(data.badge);
          setAdminMsg('🎉 ¡ACCESO MAESTRO CONCEDIDO! Modo VIP activado de por vida.', '#10b981');
          showToast('¡Bienvenido Yaquito! Modo VIP Maestro Activado.', 'success');
          setTimeout(() => {
            if (vipModal) vipModal.style.display = 'none';
          }, 1500);
        } else {
          setAdminMsg(`❌ ${data.error || 'Código inválido o no reconocido.'}`, '#ef4444');
        }
      } catch (err) {
        setAdminMsg('Error de conexión al validar código.', '#ef4444');
      } finally {
        btnApplyAdminCode.disabled = false;
        btnApplyAdminCode.textContent = 'Desbloquear Todo';
      }
    });

    adminCodeInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') btnApplyAdminCode.click();
    });
  }

  function setAdminMsg(text, color) {
    if (adminStatusMsg) {
      adminStatusMsg.textContent = text;
      adminStatusMsg.style.color = color;
    }
  }

  // Mode Toggles (Video vs Audio Only)
  if (pillVideoMode && pillAudioOnlyMode) {
    pillVideoMode.addEventListener('click', () => {
      selectedMode = 'video';
      pillVideoMode.classList.add('active');
      pillAudioOnlyMode.classList.remove('active');
      if (resolutionCol) resolutionCol.style.display = 'flex';
      if (audioFormatCol) audioFormatCol.style.display = 'none';
      if (btnDownloadText) btnDownloadText.textContent = 'DESCARGAR AHORA';
    });

    pillAudioOnlyMode.addEventListener('click', () => {
      selectedMode = 'audio';
      pillAudioOnlyMode.classList.add('active');
      pillVideoMode.classList.remove('active');
      if (resolutionCol) resolutionCol.style.display = 'none';
      if (audioFormatCol) audioFormatCol.style.display = 'flex';
      if (btnDownloadText) btnDownloadText.textContent = 'DESCARGAR SOLO AUDIO';
    });
  }

  // Paste from Clipboard
  if (btnPaste && urlInput) {
    btnPaste.addEventListener('click', async () => {
      try {
        const text = await navigator.clipboard.readText();
        if (text && text.trim().startsWith('http')) {
          urlInput.value = text.trim();
          showToast('Enlace pegado del portapapeles', 'info');
          analyzeUrl();
        } else {
          showToast('El portapapeles no contiene una URL válida.', 'warning');
        }
      } catch (err) {
        showToast('Pega el enlace manualmente en el campo.', 'info');
      }
    });
  }

  // Enter Key on URL Input
  if (urlInput) {
    urlInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') analyzeUrl();
    });
  }

  // Analyze Button
  if (btnAnalyze) {
    btnAnalyze.addEventListener('click', analyzeUrl);
  }

  // Audio Pills Container Delegation
  if (audioPillsContainer) {
    audioPillsContainer.addEventListener('click', (e) => {
      const pill = e.target.closest('.audio-pill');
      if (!pill) return;

      // Check VIP gate for Multi-Audio
      if (pill.dataset.id === 'all' && !isUserVip()) {
        if (vipNoticeBanner) vipNoticeBanner.style.display = 'block';
        if (vipModal) vipModal.style.display = 'flex';
        showToast('El modo Multi-Audio MKV requiere Bateyero VIP.', 'warning');
        return;
      }

      audioPillsContainer.querySelectorAll('.audio-pill').forEach(p => p.classList.remove('selected'));
      pill.classList.add('selected');
      selectedAudioTrack = pill.dataset.id || 'default';
      selectedAudioLang = pill.dataset.lang || '';
      if (selectedTrackName) {
        selectedTrackName.textContent = `Pista: ${pill.textContent.trim()}`;
      }
    });
  }

  // Start Download
  if (btnStartDownload) {
    btnStartDownload.addEventListener('click', startDownload);
  }

  // Refresh Library
  if (btnRefreshLibrary) {
    btnRefreshLibrary.addEventListener('click', () => {
      loadDownloadsLibrary();
      showToast('Lista de descargas actualizada', 'info');
    });
  }

  // Open Project Downloads Folder
  if (btnOpenDownloadsFolder) {
    btnOpenDownloadsFolder.addEventListener('click', () => {
      fetch('/api/open-folder', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ target: 'omni' }),
      })
      .then(r => r.json())
      .then(d => {
        if (d.cloud) {
          showToast('Servidor en la nube: descarga los archivos directamente de la lista.', 'info');
        } else {
          showToast('Carpeta abierta en tu explorador de archivos.', 'success');
        }
      })
      .catch(() => showToast('Error al solicitar abrir carpeta', 'error'));
    });
  }

  // Modal Closures
  if (btnCloseModal) btnCloseModal.addEventListener('click', closeModal);
  if (modalBackdrop) modalBackdrop.addEventListener('click', closeModal);

  function closeModal() {
    if (playerModal) playerModal.style.display = 'none';
    if (modalMediaContainer) modalMediaContainer.innerHTML = '';
  }

  // Post Download Action Handlers
  if (btnDirectDownloadBrowser) {
    btnDirectDownloadBrowser.addEventListener('click', () => {
      if (lastDownloadedFilename) {
        window.location.href = `/api/download-file?name=${encodeURIComponent(lastDownloadedFilename)}`;
        showToast('Descarga iniciada en tu navegador', 'success');
      }
    });
  }

  if (btnCopyToWindows) {
    btnCopyToWindows.addEventListener('click', async () => {
      if (!lastDownloadedFilename) return;
      btnCopyToWindows.disabled = true;
      btnCopyToWindows.innerHTML = `<span>Copiando...</span>`;

      try {
        const res = await fetch('/api/copy-to-pc', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ filename: lastDownloadedFilename }),
        });
        const data = await res.json();
        if (data.success) {
          btnCopyToWindows.innerHTML = `<span>✅ En Descargas PC</span>`;
          showToast('Archivo guardado en tu carpeta Descargas de Windows.', 'success');
        } else {
          showToast(data.error || 'No disponible en este entorno', 'warning');
          btnCopyToWindows.innerHTML = `<span>Guardar en PC</span>`;
        }
      } catch (e) {
        showToast('Error de conexión con el servidor', 'error');
        btnCopyToWindows.innerHTML = `<span>Guardar en PC</span>`;
      } finally {
        btnCopyToWindows.disabled = false;
      }
    });
  }

  if (btnOpenInExplorer) {
    btnOpenInExplorer.addEventListener('click', () => {
      if (!lastDownloadedFilename) return;
      fetch('/api/open-folder', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filename: lastDownloadedFilename }),
      })
      .then(r => r.json())
      .then(d => {
        if (d.cloud) {
          showToast('En la nube: usa el botón "Descargar al Navegador".', 'info');
        } else {
          showToast('Archivo seleccionado en el explorador', 'success');
        }
      });
    });
  }

  if (btnPlayFinished) {
    btnPlayFinished.addEventListener('click', () => {
      if (lastDownloadedFilename) {
        const isVideo = ['.mp4', '.mkv', '.webm'].some(ext => lastDownloadedFilename.toLowerCase().endsWith(ext));
        openPlayerModal(lastDownloadedFilename, isVideo);
      }
    });
  }

  if (btnPreviewPlay) {
    btnPreviewPlay.addEventListener('click', () => {
      if (currentMediaData && currentMediaData.id) {
        const previewUrl = `https://www.youtube.com/embed/${currentMediaData.id}?autoplay=1`;
        if (modalTitle) modalTitle.textContent = currentMediaData.title;
        if (modalMediaContainer) {
          modalMediaContainer.innerHTML = `
            <iframe 
              src="${previewUrl}" 
              width="100%" 
              height="450" 
              frameborder="0" 
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
              allowfullscreen 
              style="border-radius: 8px;">
            </iframe>
          `;
        }
        if (playerModal) playerModal.style.display = 'flex';
      }
    });
  }

  // --- Network Functions ---

  async function checkServerStatus() {
    try {
      const res = await fetch('/api/status');
      const data = await res.json();
      if (data.status === 'ready') {
        isServerCloud = Boolean(data.isCloud);
        const badge = $('engineStatusBadge');
        if (badge) {
          const modeLabel = isServerCloud ? 'Cloud Online' : 'Motor Local Activo';
          badge.innerHTML = `<span class="pulse-dot"></span><span>${modeLabel}</span>`;
        }
      }
    } catch (e) {
      console.warn('Backend aún conectando...');
    }
  }

  async function analyzeUrl() {
    const rawUrl = urlInput ? urlInput.value.trim() : '';
    if (!rawUrl) {
      showToast('Ingresa una URL válida primero.', 'warning');
      return;
    }

    if (btnText) btnText.style.display = 'none';
    if (spinnerSmall) spinnerSmall.style.display = 'block';
    if (btnAnalyze) btnAnalyze.disabled = true;

    try {
      const res = await fetch('/api/inspect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: rawUrl }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'No se pudo analizar el video.');

      currentMediaData = data;
      renderMediaOptions(data);
      showToast('Video analizado con éxito. Selecciona tu pista de audio.', 'success');
    } catch (err) {
      showToast('Error al analizar: ' + err.message, 'error', 4500);
    } finally {
      if (btnText) btnText.style.display = 'block';
      if (spinnerSmall) spinnerSmall.style.display = 'none';
      if (btnAnalyze) btnAnalyze.disabled = false;
    }
  }

  function renderMediaOptions(data) {
    if (mediaTitle) mediaTitle.textContent = data.title;
    if (mediaAuthor) mediaAuthor.textContent = data.uploader;
    if (mediaPlatform) mediaPlatform.textContent = data.extractor;
    if (mediaDuration) mediaDuration.textContent = data.durationFormatted;
    if (data.thumbnail && mediaThumb) mediaThumb.src = data.thumbnail;

    if (multiAudioBadge) {
      if (data.hasMultiAudio) {
        multiAudioBadge.style.display = 'inline-block';
        multiAudioBadge.textContent = `MULTI-AUDIO (${data.audioTracks.length} PISTAS)`;
      } else {
        multiAudioBadge.style.display = 'none';
      }
    }

    renderAudioPills(data.audioTracks);
  }

  function renderAudioPills(tracks) {
    if (!audioPillsContainer) return;
    audioPillsContainer.innerHTML = '';
    
    let defaultSelected = false;
    const spanishTrack = (tracks || []).find(t => t.language && t.language.startsWith('es'));

    // 1. Spanish track prioritized
    if (spanishTrack) {
      const esBtn = document.createElement('button');
      esBtn.className = 'audio-pill selected highlight-es';
      esBtn.dataset.id = spanishTrack.formatId;
      esBtn.dataset.lang = spanishTrack.language;
      esBtn.textContent = `🇪🇸 ${spanishTrack.languageLabel} (Doblaje)`;
      audioPillsContainer.appendChild(esBtn);
      selectedAudioTrack = spanishTrack.formatId;
      selectedAudioLang = spanishTrack.language;
      defaultSelected = true;
      if (selectedTrackName) selectedTrackName.textContent = `Pista: 🇪🇸 ${spanishTrack.languageLabel}`;
    }

    // 2. Multi-Audio MKV option
    if (tracks && tracks.length > 1) {
      const multiBtn = document.createElement('button');
      multiBtn.className = 'audio-pill highlight-multi';
      multiBtn.dataset.id = 'all';
      multiBtn.dataset.lang = 'all';
      multiBtn.textContent = '🌐 Multi-Audio MKV (Todas las pistas)';
      audioPillsContainer.appendChild(multiBtn);
    }

    // 3. Best Auto Track
    const defBtn = document.createElement('button');
    defBtn.className = 'audio-pill' + (!defaultSelected ? ' selected' : '');
    defBtn.dataset.id = 'default';
    defBtn.dataset.lang = 'auto';
    defBtn.textContent = '⭐ Mejor Audio (Auto)';
    audioPillsContainer.appendChild(defBtn);

    if (!defaultSelected) {
      selectedAudioTrack = 'default';
      selectedAudioLang = 'auto';
      if (selectedTrackName) selectedTrackName.textContent = 'Pista: ⭐ Mejor Audio (Auto)';
    }

    // 4. Other tracks
    if (tracks && tracks.length > 0) {
      tracks.forEach(t => {
        if (spanishTrack && t.formatId === spanishTrack.formatId) return;

        const pill = document.createElement('button');
        pill.className = 'audio-pill';
        pill.dataset.id = t.formatId;
        pill.dataset.lang = t.language;
        
        let flag = '🎵';
        if (t.language.startsWith('es')) flag = '🇪🇸';
        else if (t.language.startsWith('en')) flag = '🇬🇧';
        else if (t.language.startsWith('fr')) flag = '🇫🇷';
        else if (t.language.startsWith('ja')) flag = '🇯🇵';
        else if (t.language.startsWith('de')) flag = '🇩🇪';
        else if (t.language.startsWith('pt')) flag = '🇧🇷';
        else if (t.language.startsWith('it')) flag = '🇮🇹';

        pill.textContent = `${flag} ${t.languageLabel} ${t.isDub ? '(Doblaje)' : (t.isOriginal ? '(Original)' : '')}`;
        audioPillsContainer.appendChild(pill);
      });
    }
  }

  async function startDownload() {
    const rawUrl = urlInput ? urlInput.value.trim() : '';
    if (!rawUrl) {
      showToast('Ingresa una URL antes de descargar.', 'warning');
      return;
    }

    const payload = {
      url: rawUrl,
      type: selectedMode,
      videoQuality: videoQualitySelect ? videoQualitySelect.value : '720',
      audioTrack: selectedAudioTrack,
      audioLang: selectedAudioLang,
      audioFormat: audioFormatSelect ? audioFormatSelect.value : 'mp3',
      embedSubs: embedSubsCheck ? embedSubsCheck.checked : false,
    };

    if (btnStartDownload) btnStartDownload.disabled = true;
    if (btnDownloadText) btnDownloadText.textContent = 'INICIANDO...';
    if (progressActionsRow) progressActionsRow.style.display = 'none';

    try {
      const res = await fetch('/api/download', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Error al iniciar la descarga.');

      showToast('Descarga iniciada con éxito.', 'info');
      trackProgress(data.downloadId);
    } catch (err) {
      showToast('Error al solicitar descarga: ' + err.message, 'error', 4500);
      if (btnStartDownload) btnStartDownload.disabled = false;
      if (btnDownloadText) {
        btnDownloadText.textContent = selectedMode === 'video' ? 'DESCARGAR AHORA' : 'DESCARGAR SOLO AUDIO';
      }
    }
  }

  function trackProgress(downloadId) {
    if (activeEventSource) activeEventSource.close();

    if (progressFooterCard) {
      progressFooterCard.style.display = 'block';
      progressFooterCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }

    if (progressBarNeon) progressBarNeon.style.width = '0%';
    if (progressPercentBadge) progressPercentBadge.textContent = '0%';
    if (progressFileText) {
      progressFileText.textContent = currentMediaData ? `Descargando: ${currentMediaData.title}` : 'Iniciando descarga...';
    }
    if (progressActionsRow) progressActionsRow.style.display = 'none';

    const evtSource = new EventSource(`/api/progress?id=${downloadId}`);
    activeEventSource = evtSource;

    evtSource.onmessage = (e) => {
      try {
        const p = JSON.parse(e.data);
        const percent = Math.round(p.percent || 0);

        if (progressBarNeon) progressBarNeon.style.width = `${percent}%`;
        if (progressPercentBadge) progressPercentBadge.textContent = `${percent}%`;

        if (p.size && progressSize) progressSize.textContent = p.size;
        if (p.speed && progressSpeed) progressSpeed.textContent = p.speed;
        if (p.eta && progressEta) progressEta.textContent = `${p.eta} restante`;
        if (p.filename) lastDownloadedFilename = p.filename;

        if (p.status === 'processing') {
          if (progressFileText) progressFileText.textContent = 'Mezclando video y pista de audio seleccionada con FFmpeg...';
        } else if (p.status === 'completed') {
          if (progressFileText) progressFileText.textContent = '✅ ¡Descarga completada con éxito!';
          if (progressBarNeon) progressBarNeon.style.width = '100%';
          if (progressPercentBadge) progressPercentBadge.textContent = '100%';
          evtSource.close();
          if (btnStartDownload) btnStartDownload.disabled = false;
          if (btnDownloadText) {
            btnDownloadText.textContent = selectedMode === 'video' ? 'DESCARGAR AHORA' : 'DESCARGAR SOLO AUDIO';
          }
          
          if (progressActionsRow) progressActionsRow.style.display = 'flex';
          showToast('🎉 ¡Descarga finalizada! Ya puedes descargarla o reproducirla.', 'success', 5000);
          loadDownloadsLibrary();
        } else if (p.status === 'error') {
          if (progressFileText) progressFileText.textContent = `❌ ${p.error}`;
          evtSource.close();
          if (btnStartDownload) btnStartDownload.disabled = false;
          if (btnDownloadText) {
            btnDownloadText.textContent = selectedMode === 'video' ? 'DESCARGAR AHORA' : 'DESCARGAR SOLO AUDIO';
          }
          showToast(`Error: ${p.error}`, 'error', 5000);
        }
      } catch (err) {
        console.error('Error in SSE message:', err);
      }
    };

    evtSource.onerror = () => {
      evtSource.close();
      if (btnStartDownload) btnStartDownload.disabled = false;
    };
  }

  async function loadDownloadsLibrary() {
    if (!downloadsItemsList) return;
    try {
      const res = await fetch('/api/downloads');
      const data = await res.json();

      if (downloadsCount) {
        downloadsCount.textContent = (data.files || []).length;
      }

      if (!data.files || data.files.length === 0) {
        downloadsItemsList.innerHTML = `
          <div style="text-align:center; padding: 2.5rem 1rem; color: var(--text-muted); font-size: 0.85rem;">
            <p>No hay descargas guardadas todavía.</p>
            <span style="font-size:0.75rem;">Ingresa un enlace y pulsa ANALYZE para empezar.</span>
          </div>
        `;
        return;
      }

      downloadsItemsList.innerHTML = '';
      data.files.forEach((file, index) => {
        const isVideo = ['.mp4', '.mkv', '.webm'].includes(file.ext);
        const item = document.createElement('div');
        item.className = 'queue-item';

        item.innerHTML = `
          <div class="queue-item-header">
            <span class="queue-name" title="${file.name}">${index + 1}. ${file.name}</span>
          </div>
          <div class="queue-meta-row">
            <div class="queue-tags">
              <span class="tag-type">${isVideo ? 'Video' : 'Audio'}</span>
              <span class="meta-dot">•</span>
              <span>${file.sizeFormatted}</span>
              <span class="meta-dot">•</span>
              <span class="status-completed">Listo</span>
            </div>
            <div class="queue-action-buttons">
              <button class="btn-clean-action btn-play" title="Ver en navegador">
                <svg viewBox="0 0 24 24" width="11" height="11" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>
                <span>Play</span>
              </button>
              <a href="/api/download-file?name=${encodeURIComponent(file.name)}" download class="btn-clean-action btn-save-pc" title="Descargar directo al navegador">
                <svg viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>
                <span>Descargar</span>
              </a>
              <button class="btn-clean-action btn-copy-pc" title="Guardar en carpeta Descargas">
                <svg viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>
                <span>A Windows</span>
              </button>
            </div>
          </div>
        `;

        item.querySelector('.btn-play').addEventListener('click', () => {
          openPlayerModal(file.name, isVideo);
        });

        item.querySelector('.btn-copy-pc').addEventListener('click', async (e) => {
          const btn = e.currentTarget;
          btn.innerHTML = `<span>...</span>`;
          try {
            const r = await fetch('/api/copy-to-pc', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ filename: file.name }),
            });
            const d = await r.json();
            if (d.success) {
              btn.innerHTML = `<span>✅ En PC</span>`;
              showToast('Copiado a tu carpeta Descargas de Windows.', 'success');
              setTimeout(() => {
                btn.innerHTML = `
                  <svg viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>
                  <span>A Windows</span>
                `;
              }, 2500);
            } else {
              showToast(d.error || 'Usa el botón Descargar', 'warning');
              btn.innerHTML = `<span>A Windows</span>`;
            }
          } catch (err) {
            showToast('Error de conexión', 'error');
            btn.innerHTML = `<span>A Windows</span>`;
          }
        });

        downloadsItemsList.appendChild(item);
      });
    } catch (e) {
      console.error('Error loading library:', e);
    }
  }

  function openPlayerModal(fileName, isVideo) {
    if (modalTitle) modalTitle.textContent = fileName;
    const mediaUrl = `/api/file?name=${encodeURIComponent(fileName)}`;

    if (modalMediaContainer) {
      if (isVideo) {
        modalMediaContainer.innerHTML = `
          <video controls autoplay playsinline style="max-height: 70vh; width:100%; border-radius: 8px;">
            <source src="${mediaUrl}">
            Tu navegador no soporta reproducción directa de este formato. Usa el botón "Descargar".
          </video>
        `;
      } else {
        modalMediaContainer.innerHTML = `
          <div style="width:100%; text-align:center; padding: 2.5rem 0;">
            <audio controls autoplay style="width: 85%;">
              <source src="${mediaUrl}">
            </audio>
          </div>
        `;
      }
    }
    if (playerModal) playerModal.style.display = 'flex';
  }

  // --- Auto-detect ?url= Query Parameter from Chrome Extension ---
  const urlParams = new URLSearchParams(window.location.search);
  const paramUrl = urlParams.get('url');
  if (paramUrl && urlInput) {
    urlInput.value = paramUrl;
    setTimeout(() => {
      analyzeUrl();
    }, 400);
  }

  // --- Initial Boot ---
  checkServerStatus();
  loadDownloadsLibrary();

  // --- Easter Eggs (Yaquito & Edwin Petit) ---
  console.log(
    '%c⚡ BATEYERODOWNLOADER PRO ⚡\n%cCreated by YAQUITO\n%cArchitected & Engineered with Precision by EDWIN PETIT\n%cStatus: High-Performance Engine Active',
    'color: #00f2fe; font-size: 18px; font-weight: 900; text-shadow: 0 0 8px rgba(0,242,254,0.6);',
    'color: #fbbf24; font-size: 14px; font-weight: bold;',
    'color: #a78bfa; font-size: 12px; font-style: italic;',
    'color: #34d399; font-size: 11px;'
  );

  let logoClickCount = 0;
  let logoTimer = null;
  if (appLogo) {
    appLogo.addEventListener('click', () => {
      logoClickCount++;
      clearTimeout(logoTimer);
      if (logoClickCount >= 3) {
        showToast('⚡ BATEYERODOWNLOADER PRO • Created by YAQUITO • Engineering: EDWIN PETIT', 'info', 6000);
        logoClickCount = 0;
      }
      logoTimer = setTimeout(() => { logoClickCount = 0; }, 600);
    });
  }
});
