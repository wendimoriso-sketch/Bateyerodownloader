const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');
const crypto = require('crypto');
const { spawn, exec } = require('child_process');

const PORT = parseInt(process.env.PORT, 10) || 3000;
const BASE_DIR = __dirname;
const BIN_DIR = path.join(BASE_DIR, 'bin');
const DOWNLOADS_DIR = path.join(BASE_DIR, 'downloads');
const PUBLIC_DIR = path.join(BASE_DIR, 'public');

// Hybrid binary and OS resolution
const isWin = process.platform === 'win32';
const USER_HOME = process.env.USERPROFILE || process.env.HOME || (isWin ? 'C:\\Users\\lites' : '/tmp');
const USER_DOWNLOADS_DIR = path.join(USER_HOME, 'Downloads');

const hasLocalYtdlp = isWin && fs.existsSync(path.join(BIN_DIR, 'yt-dlp.exe'));
const hasLocalFfmpeg = isWin && fs.existsSync(path.join(BIN_DIR, 'ffmpeg.exe'));
const hasLocalNode = isWin && fs.existsSync(path.join(BIN_DIR, 'node.exe'));

const YTDLP_BIN = hasLocalYtdlp ? path.join(BIN_DIR, 'yt-dlp.exe') : 'yt-dlp';
const FFMPEG_BIN = hasLocalFfmpeg ? path.join(BIN_DIR, 'ffmpeg.exe') : 'ffmpeg';
const NODE_BIN = hasLocalNode ? path.join(BIN_DIR, 'node.exe') : process.execPath;

// Ultra-secure Master License Key (SHA-256 protected, never exposed in client plain text)
const MASTER_KEY_RAW = 'YAQ-9842-K7X9-VIP-ALPHA-2026';
const MASTER_KEY_HASH = crypto.createHash('sha256').update(MASTER_KEY_RAW).digest('hex');

// Ensure directories exist
if (!fs.existsSync(DOWNLOADS_DIR)) {
  fs.mkdirSync(DOWNLOADS_DIR, { recursive: true });
}

// Environment with BIN_DIR in PATH so yt-dlp finds node and ffmpeg seamlessly
const SPAWN_ENV = {
  ...process.env,
  PATH: `${BIN_DIR}${path.delimiter}${process.env.PATH || ''}`,
};

// Active SSE client listeners and download processes
const activeDownloads = new Map(); // id -> { process, subscribers: Set, progress: {...} }

// Helper for MIME types
const MIME_TYPES = {
  '.html': 'text/html; charset=UTF-8',
  '.css': 'text/css; charset=UTF-8',
  '.js': 'application/javascript; charset=UTF-8',
  '.json': 'application/json',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.mp4': 'video/mp4',
  '.webm': 'video/webm',
  '.mkv': 'video/x-matroska',
  '.mp3': 'audio/mpeg',
  '.m4a': 'audio/mp4',
  '.wav': 'audio/wav',
};

// Language map for prettier labels
const LANGUAGE_NAMES = {
  es: 'Español',
  'es-es': 'Español (España)',
  'es-419': 'Español (Latinoamérica)',
  'es-la': 'Español (Latinoamérica)',
  en: 'Inglés (English)',
  'en-us': 'Inglés (EE.UU.)',
  'en-gb': 'Inglés (Reino Unido)',
  ja: 'Japonés (日本語)',
  fr: 'Francés (Français)',
  de: 'Alemán (Deutsch)',
  it: 'Italiano',
  pt: 'Portugués',
  'pt-br': 'Portugués (Brasil)',
  ko: 'Coreano (한국어)',
  ru: 'Ruso (Русский)',
  zh: 'Chino (中文)',
  'zh-hans': 'Chino Simplificado',
  'zh-hant': 'Chino Tradicional',
  hi: 'Hindi (हिन्दी)',
  ar: 'Árabe (العربية)',
};

function getLanguageLabel(code) {
  if (!code) return 'Audio Desconocido';
  const clean = code.toLowerCase().trim();
  if (LANGUAGE_NAMES[clean]) return LANGUAGE_NAMES[clean];
  const prefix = clean.split('-')[0];
  if (LANGUAGE_NAMES[prefix]) return `${LANGUAGE_NAMES[prefix]} (${clean})`;
  return `Idioma (${code.toUpperCase()})`;
}

// JSON responder
function sendJSON(res, statusCode, data) {
  res.writeHead(statusCode, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  });
  res.end(JSON.stringify(data));
}

// Inspect URL via yt-dlp
function inspectUrl(targetUrl) {
  return new Promise((resolve, reject) => {
    const args = ['--dump-json', '--no-playlist'];

    if (hasLocalFfmpeg) {
      args.push('--ffmpeg-location', BIN_DIR);
    }
    if (hasLocalNode) {
      args.push('--js-runtimes', `node:${NODE_BIN}`);
    }

    args.push(targetUrl);

    const proc = spawn(YTDLP_BIN, args, { windowsHide: true, env: SPAWN_ENV });
    let stdoutData = '';
    let stderrData = '';

    proc.stdout.on('data', (d) => { stdoutData += d.toString('utf8'); });
    proc.stderr.on('data', (d) => { stderrData += d.toString('utf8'); });

    proc.on('close', (code) => {
      if (code !== 0) {
        return reject(new Error(stderrData || `yt-dlp exited with code ${code}`));
      }
      try {
        let jsonStr = stdoutData.trim();
        const firstBrace = jsonStr.indexOf('{');
        const lastBrace = jsonStr.lastIndexOf('}');
        if (firstBrace !== -1 && lastBrace !== -1) {
          jsonStr = jsonStr.substring(firstBrace, lastBrace + 1);
        }
        const info = JSON.parse(jsonStr);
        resolve(info);
      } catch (e) {
        console.error('JSON parse error on inspect output:', e.message, stdoutData.substring(0, 300));
        reject(new Error('Failed to parse yt-dlp output as JSON'));
      }
    });
    proc.on('error', (err) => reject(err));
  });
}

// Parse inspect result into clean options
function processMediaInfo(info) {
  const formats = (info.formats || []).slice();
  
  // Sort formats by bitrate descending first so best audio stream is preserved!
  formats.sort((a, b) => (b.abr || b.tbr || 0) - (a.abr || a.tbr || 0));

  // Extract separate audio streams
  const audioTracks = [];
  const seenAudioKeys = new Set();

  for (const f of formats) {
    if (f.format_id && f.format_id.startsWith('sb')) continue;
    if (f.format_note && f.format_note.toLowerCase().includes('storyboard')) continue;
    if (f.ext === 'mhtml' || f.vcodec === 'mhtml') continue;
    if (f.acodec === 'none' || (!f.acodec && !f.audio_channels)) continue;

    const note = (f.format_note || '').toLowerCase();
    const lang = f.language || (f.format_note && f.format_note.match(/[a-z]{2}(-[A-Z]{2,3})?/i) ? f.format_note : null);
    
    // Check if it's original or dubbed
    const isOriginal = note.includes('original') || (!note.includes('dub') && !lang);
    const isDub = note.includes('dub') || (!isOriginal && lang);
    const abr = Math.round(f.abr || f.tbr || 0);
    const langLabel = getLanguageLabel(lang);

    // Unique per language + dub type (keeps highest bitrate because sorted descending)
    const key = `${lang || 'und'}-${isDub ? 'dub' : 'orig'}`;
    if (!seenAudioKeys.has(key)) {
      seenAudioKeys.add(key);
      audioTracks.push({
        formatId: f.format_id,
        ext: f.ext,
        language: lang || 'und',
        languageLabel: langLabel,
        isDub: Boolean(isDub),
        isOriginal: Boolean(isOriginal),
        note: f.format_note || '',
        abr: abr,
        filesize: f.filesize || f.filesize_approx || null,
        label: `${langLabel} ${isDub ? '• Doblado' : (isOriginal ? '• Original' : '')} (${f.ext.toUpperCase()}${abr ? ' ' + abr + ' kbps' : ''})`.trim()
      });
    }
  }

  // Sort audio tracks: original first, then spanish, then english, then others
  audioTracks.sort((a, b) => {
    if (a.isOriginal && !b.isOriginal) return -1;
    if (!a.isOriginal && b.isOriginal) return 1;
    if (a.language.startsWith('es') && !b.language.startsWith('es')) return -1;
    if (!a.language.startsWith('es') && b.language.startsWith('es')) return 1;
    return a.languageLabel.localeCompare(b.languageLabel);
  });

  // Extract video qualities
  const videoQualities = [
    { id: 'best', label: 'Máxima Calidad Disponible (Auto)' },
    { id: '2160', label: '4K Ultra HD (2160p)' },
    { id: '1440', label: '2K Quad HD (1440p)' },
    { id: '1080', label: 'Full HD (1080p)' },
    { id: '720', label: 'HD (720p)' },
    { id: '480', label: 'SD (480p)' },
  ];

  // Available subtitles
  const subtitles = [];
  if (info.subtitles) {
    for (const [lang, list] of Object.entries(info.subtitles)) {
      subtitles.push({ lang, label: getLanguageLabel(lang), auto: false });
    }
  }
  if (info.automatic_captions) {
    for (const [lang, list] of Object.entries(info.automatic_captions)) {
      if (!subtitles.find(s => s.lang === lang)) {
        subtitles.push({ lang, label: `${getLanguageLabel(lang)} (Auto)`, auto: true });
      }
    }
  }

  return {
    id: info.id,
    title: info.title || 'Video sin título',
    uploader: info.uploader || info.channel || 'Desconocido',
    duration: info.duration || 0,
    durationFormatted: formatDuration(info.duration || 0),
    thumbnail: info.thumbnail || '',
    webpageUrl: info.webpage_url || '',
    extractor: info.extractor_key || info.extractor || 'Web',
    hasMultiAudio: audioTracks.length > 1,
    audioTracks,
    videoQualities,
    subtitles,
  };
}

function formatDuration(seconds) {
  if (!seconds) return '0:00';
  const hrs = Math.floor(seconds / 3600);
  const mins = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);
  if (hrs > 0) {
    return `${hrs}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  }
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}

// Build foolproof yt-dlp audio format selector
function buildAudioFormatSelector(audioTrack, audioLang) {
  if (!audioTrack || audioTrack === 'default') {
    return 'bestaudio/best';
  }

  const trackStr = String(audioTrack).toLowerCase();
  const langStr = String(audioLang || '').toLowerCase();

  const isSpanish = trackStr === 'es' || trackStr.includes('dub-es') || trackStr.includes('es-') || trackStr.startsWith('es') || langStr.startsWith('es');
  const isEnglish = trackStr === 'en' || trackStr.includes('orig-en') || trackStr.includes('en-') || trackStr.startsWith('en') || langStr.startsWith('en');

  const selectors = [];

  // If a real yt-dlp format ID was selected (e.g., "251-8" or "140-9")
  if (/^[\d]+(-[\d]+)?$/.test(audioTrack)) {
    selectors.push(audioTrack);
  }

  if (isSpanish) {
    selectors.push(
      'bestaudio[language^=es]',
      'bestaudio[language=es-419]',
      'bestaudio[language=es-la]',
      'bestaudio[language=es-es]',
      'bestaudio[format_note*=Spanish]',
      'bestaudio[format_note*=Español]',
      'bestaudio[format_note*=spanish]',
      'bestaudio[format_note*=español]'
    );
  } else if (isEnglish) {
    selectors.push(
      'bestaudio[language^=en]',
      'bestaudio[format_note*=English]',
      'bestaudio[format_note*=original]'
    );
  } else if (langStr && langStr !== 'und' && langStr !== 'auto') {
    selectors.push(`bestaudio[language^=${langStr}]`);
  }

  selectors.push('bestaudio/best');
  return selectors.join('/');
}

// Server Creation
const server = http.createServer((req, res) => {
  const parsedUrl = url.parse(req.url, true);
  const pathname = parsedUrl.pathname;

  // CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  // --- API: Status ---
  if (pathname === '/api/status' && req.method === 'GET') {
    const isCloud = !isWin || Boolean(process.env.PORT || process.env.RENDER || process.env.RAILWAY_STATIC_URL);
    return sendJSON(res, 200, {
      status: 'ready',
      version: '2.0.0',
      isCloud,
      platform: process.platform,
      ytdlp: true,
      ffmpeg: true,
      downloadsFolder: DOWNLOADS_DIR,
      userDownloadsFolder: USER_DOWNLOADS_DIR,
      userDownloadsExists: fs.existsSync(USER_DOWNLOADS_DIR),
    });
  }

  // --- API: Verify Master Admin License ---
  if (pathname === '/api/verify-license' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', () => {
      try {
        const { key } = JSON.parse(body || '{}');
        if (!key || typeof key !== 'string') {
          return sendJSON(res, 400, { success: false, error: 'Código de licencia requerido.' });
        }
        const cleanKey = key.trim().toUpperCase();
        const keyHash = crypto.createHash('sha256').update(cleanKey).digest('hex');

        const envKey = process.env.ADMIN_MASTER_KEY ? process.env.ADMIN_MASTER_KEY.trim().toUpperCase() : null;
        const envHash = envKey ? crypto.createHash('sha256').update(envKey).digest('hex') : null;

        if (keyHash === MASTER_KEY_HASH || (envHash && keyHash === envHash)) {
          const token = crypto.createHmac('sha256', 'bateyero_master_secret').update(cleanKey + '_lifetime_vip').digest('hex');
          return sendJSON(res, 200, {
            success: true,
            token,
            badge: '👑 VIP ADMIN (YAQUITO)',
            message: '¡Licencia de Administrador Maestro Activada de por Vida!'
          });
        }
        return sendJSON(res, 401, { success: false, error: 'Código de Administrador incorrecto o no autorizado.' });
      } catch (err) {
        return sendJSON(res, 500, { success: false, error: err.message });
      }
    });
    return;
  }

  // --- API: Inspect URL ---
  if (pathname === '/api/inspect' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', async () => {
      try {
        const { url: mediaUrl } = JSON.parse(body || '{}');
        if (!mediaUrl) {
          return sendJSON(res, 400, { error: 'Debes proporcionar una URL válida.' });
        }
        const info = await inspectUrl(mediaUrl);
        const processed = processMediaInfo(info);
        return sendJSON(res, 200, processed);
      } catch (err) {
        console.error('Error inspecting URL:', err.message);
        return sendJSON(res, 500, { error: err.message || 'Error al inspeccionar la URL.' });
      }
    });
    return;
  }

  // --- API: Start Download ---
  if (pathname === '/api/download' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', () => {
      try {
        const options = JSON.parse(body || '{}');
        const {
          url: mediaUrl,
          type = 'video', // 'video' | 'audio'
          videoQuality = 'best',
          audioTrack = 'default', // 'default' | 'all' | formatId | 'es'
          audioLang = '',
          audioFormat = 'mp3',
          embedSubs = false,
        } = options;

        if (!mediaUrl) {
          return sendJSON(res, 400, { error: 'Falta la URL de descarga.' });
        }

        const downloadId = Date.now().toString() + '_' + Math.random().toString(36).substring(2, 7);
        const outputTemplate = path.join(DOWNLOADS_DIR, '%(title)s [%(id)s].%(ext)s');

        // Build yt-dlp arguments cleanly
        const args = [
          '--newline',
          '--no-playlist',
          '--no-abort-on-error',
          '--ignore-errors',
          '-o', outputTemplate,
        ];

        if (hasLocalFfmpeg) {
          args.push('--ffmpeg-location', BIN_DIR);
        }

        if (hasLocalNode) {
          args.push('--js-runtimes', `node:${NODE_BIN}`);
        }

        const audioSelector = buildAudioFormatSelector(audioTrack, audioLang);
        const videoFilter = (videoQuality && videoQuality !== 'best') 
          ? `bv*[height<=${videoQuality}]` 
          : 'bv*';

        if (type === 'audio') {
          // Audio extraction mode
          let fmt = audioFormat || 'mp3';
          let quality = '0';
          if (fmt === 'mp3_320') {
            fmt = 'mp3';
            quality = '320k';
          } else if (fmt === 'mp3_192') {
            fmt = 'mp3';
            quality = '192k';
          }
          args.push('-x', '--audio-format', fmt, '--audio-quality', quality);
          args.push('-f', `${audioSelector}/ba*/best`);
        } else {
          // Video mode
          if (audioTrack === 'all') {
            args.push('--audio-multistreams');
            args.push('-f', `${videoFilter}+ba*/bv*+ba*/b`);
            args.push('--merge-output-format', 'mkv');
          } else {
            // Selected audio track with robust fallback
            args.push('-f', `${videoFilter}+${audioSelector}/${videoFilter}+ba*/bv*+ba*/b`);
            args.push('--merge-output-format', 'mp4');
          }

          if (embedSubs) {
            args.push('--embed-subs', '--sub-langs', 'es.*,en.*', '--compat-options', 'no-abort-on-error');
          }
        }

        // Add URL at the end
        args.push(mediaUrl);

        // Spawn yt-dlp with custom environment
        const proc = spawn(YTDLP_BIN, args, { windowsHide: true, env: SPAWN_ENV });
        let stderrBuffer = '';

        const record = {
          id: downloadId,
          process: proc,
          subscribers: new Set(),
          progress: {
            percent: 0,
            speed: '',
            eta: '',
            size: '',
            status: 'starting',
            filename: '',
            error: null,
          },
        };

        activeDownloads.set(downloadId, record);

        // Broadcast helper
        const broadcast = (data) => {
          Object.assign(record.progress, data);
          for (const sub of record.subscribers) {
            try {
              sub.write(`data: ${JSON.stringify(record.progress)}\n\n`);
            } catch (e) {
              record.subscribers.delete(sub);
            }
          }
        };

        // Parse stdout for progress updates
        proc.stdout.on('data', (data) => {
          const text = data.toString('utf8');
          const lines = text.split('\n');

          for (const line of lines) {
            const cleanLine = line.trim();
            if (!cleanLine) continue;

            // [download]  45.3% of 120.50MiB at 4.52MiB/s ETA 00:15
            const downloadMatch = cleanLine.match(/\[download\]\s+([\d\.]+)%\s+of\s+([^\s]+)\s+at\s+([^\s]+)\s+ETA\s+([^\s]+)/i);
            if (downloadMatch) {
              broadcast({
                percent: parseFloat(downloadMatch[1]),
                size: downloadMatch[2],
                speed: downloadMatch[3],
                eta: downloadMatch[4],
                status: 'downloading',
              });
              continue;
            }

            // [download] Destination: C:\path\file.ext
            const destMatch = cleanLine.match(/\[download\]\s+Destination:\s+(.+)/i);
            if (destMatch) {
              broadcast({ filename: path.basename(destMatch[1].trim()), status: 'downloading' });
              continue;
            }

            // [Merger] Merging formats into "..."
            if (cleanLine.includes('[Merger]') || cleanLine.includes('[ExtractAudio]')) {
              const mergeMatch = cleanLine.match(/Merging formats into "(.+?)"/i);
              if (mergeMatch) {
                broadcast({ filename: path.basename(mergeMatch[1].trim()) });
              }
              broadcast({ status: 'processing', percent: 99 });
              continue;
            }

            // Already downloaded
            if (cleanLine.includes('has already been downloaded')) {
              broadcast({ percent: 100, status: 'completed' });
              continue;
            }
          }
        });

        proc.stderr.on('data', (data) => {
          const str = data.toString('utf8');
          stderrBuffer += str;
          console.error('[yt-dlp stderr]:', str);
          if (stderrBuffer.length > 2000) {
            stderrBuffer = stderrBuffer.substring(stderrBuffer.length - 2000);
          }
        });

        proc.on('close', (code) => {
          if (code === 0) {
            broadcast({ percent: 100, status: 'completed' });
          } else {
            const errorLines = stderrBuffer.split('\n').map(l => l.trim()).filter(l => l.startsWith('ERROR:') || l.includes('Error'));
            const errorMsg = errorLines.length > 0 ? errorLines[errorLines.length - 1] : `Error en la descarga (código ${code})`;
            broadcast({ status: 'error', error: errorMsg });
          }
          record.process = null;
        });

        proc.on('error', (err) => {
          broadcast({ status: 'error', error: err.message });
          record.process = null;
        });

        return sendJSON(res, 200, { downloadId, message: 'Descarga iniciada' });
      } catch (err) {
        return sendJSON(res, 500, { error: err.message });
      }
    });
    return;
  }

  // --- API: SSE Progress Stream ---
  if (pathname === '/api/progress' && req.method === 'GET') {
    const downloadId = parsedUrl.query.id;
    const record = activeDownloads.get(downloadId);

    if (!record) {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      res.end('Download not found');
      return;
    }

    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
      'Access-Control-Allow-Origin': '*',
    });
    res.write('\n');

    record.subscribers.add(res);
    res.write(`data: ${JSON.stringify(record.progress)}\n\n`);

    req.on('close', () => {
      record.subscribers.delete(res);
    });
    return;
  }

  // --- API: List Downloads ---
  if (pathname === '/api/downloads' && req.method === 'GET') {
    fs.readdir(DOWNLOADS_DIR, (err, files) => {
      if (err) return sendJSON(res, 500, { error: 'No se pudo leer la carpeta de descargas.' });
      
      const fileList = [];
      for (const file of files) {
        if (file.endsWith('.part') || file.endsWith('.ytdl')) continue;
        const fullPath = path.join(DOWNLOADS_DIR, file);
        try {
          const stats = fs.statSync(fullPath);
          if (stats.isFile()) {
            fileList.push({
              name: file,
              size: stats.size,
              sizeFormatted: (stats.size / (1024 * 1024)).toFixed(2) + ' MB',
              created: stats.mtime,
              ext: path.extname(file).toLowerCase(),
            });
          }
        } catch (e) {}
      }

      fileList.sort((a, b) => new Date(b.created) - new Date(a.created));
      return sendJSON(res, 200, { 
        files: fileList,
        downloadsFolder: DOWNLOADS_DIR,
        userDownloadsFolder: USER_DOWNLOADS_DIR
      });
    });
    return;
  }

  // --- API: Copy File to User's Windows Downloads Folder ---
  if (pathname === '/api/copy-to-pc' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', () => {
      try {
        if (!isWin) {
          return sendJSON(res, 400, { error: 'Estás en un servidor web remoto. Descarga directamente con el botón "Descargar".' });
        }

        const { filename } = JSON.parse(body || '{}');
        if (!filename) return sendJSON(res, 400, { error: 'Falta el nombre del archivo.' });

        const srcFile = path.join(DOWNLOADS_DIR, path.basename(filename));
        if (!fs.existsSync(srcFile)) {
          return sendJSON(res, 404, { error: 'El archivo origen no existe.' });
        }

        if (!fs.existsSync(USER_DOWNLOADS_DIR)) {
          fs.mkdirSync(USER_DOWNLOADS_DIR, { recursive: true });
        }

        const destFile = path.join(USER_DOWNLOADS_DIR, path.basename(filename));
        fs.copyFileSync(srcFile, destFile);

        return sendJSON(res, 200, { 
          success: true, 
          message: `Guardado en ${destFile}`,
          destination: destFile 
        });
      } catch (err) {
        console.error('copy-to-pc error:', err);
        return sendJSON(res, 500, { error: err.message });
      }
    });
    return;
  }

  // --- API: Open Folder in Explorer ---
  if (pathname === '/api/open-folder' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', () => {
      try {
        if (!isWin) {
          return sendJSON(res, 200, { success: true, cloud: true, message: 'Servidor en la nube activo. Archivos disponibles para descarga directa.' });
        }

        let parsed = {};
        try { parsed = JSON.parse(body || '{}'); } catch (_) { parsed = {}; }
        const { filename, target = 'omni' } = parsed;
        
        const folderToOpen = target === 'user' ? USER_DOWNLOADS_DIR : DOWNLOADS_DIR;
        const normalizedFolder = path.resolve(folderToOpen).replace(/\//g, '\\');

        if (filename && target !== 'user') {
          const targetFile = path.resolve(path.join(DOWNLOADS_DIR, path.basename(filename))).replace(/\//g, '\\');
          if (fs.existsSync(targetFile)) {
            exec(`explorer.exe /select,"${targetFile}"`);
            return sendJSON(res, 200, { success: true, opened: targetFile, type: 'file' });
          }
        }

        exec(`explorer.exe "${normalizedFolder}"`, (err) => {
          if (err) {
            exec(`start "" "${normalizedFolder}"`);
          }
        });
        return sendJSON(res, 200, { success: true, opened: normalizedFolder, type: 'folder' });
      } catch (err) {
        return sendJSON(res, 500, { error: err.message });
      }
    });
    return;
  }

  // --- API: Open Video Directly in Default Windows Player ---
  if (pathname === '/api/open-player' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', () => {
      try {
        const { filename } = JSON.parse(body || '{}');
        if (!filename) return sendJSON(res, 400, { error: 'Falta el archivo' });
        const filePath = path.join(DOWNLOADS_DIR, path.basename(filename));
        if (fs.existsSync(filePath)) {
          exec(`start "" "${filePath}"`);
          return sendJSON(res, 200, { success: true });
        }
        return sendJSON(res, 404, { error: 'Archivo no encontrado' });
      } catch (err) {
        return sendJSON(res, 500, { error: err.message });
      }
    });
    return;
  }

  // --- API: Direct Browser File Download / Stream Media ---
  if ((pathname === '/api/file' || pathname === '/api/download-file') && (req.method === 'GET' || req.method === 'HEAD')) {
    const rawFilename = parsedUrl.query.name;
    if (!rawFilename) {
      res.writeHead(400, { 'Content-Type': 'text/plain' });
      return res.end('Filename is required');
    }

    const decoded = decodeURIComponent(rawFilename);
    const safeFile = path.basename(decoded);
    const filePath = path.join(DOWNLOADS_DIR, safeFile);

    if (!fs.existsSync(filePath)) {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      return res.end(`File not found: ${safeFile}`);
    }

    const stat = fs.statSync(filePath);
    const fileSize = stat.size;
    const range = req.headers.range;
    const ext = path.extname(filePath).toLowerCase();
    const contentType = MIME_TYPES[ext] || 'application/octet-stream';
    const isAttachment = pathname === '/api/download-file' || parsedUrl.query.download === '1';

    if (isAttachment) {
      res.writeHead(200, {
        'Content-Type': contentType,
        'Content-Length': fileSize,
        'Content-Disposition': `attachment; filename="${encodeURIComponent(safeFile)}"`,
      });
      if (req.method === 'HEAD') return res.end();
      return fs.createReadStream(filePath).pipe(res);
    }

    if (range) {
      const parts = range.replace(/bytes=/, '').split('-');
      const start = parseInt(parts[0], 10);
      const end = parts[1] ? parseInt(parts[1], 10) : fileSize - 1;
      const chunksize = (end - start) + 1;
      const head = {
        'Content-Range': `bytes ${start}-${end}/${fileSize}`,
        'Accept-Ranges': 'bytes',
        'Content-Length': chunksize,
        'Content-Type': contentType,
      };
      res.writeHead(206, head);
      if (req.method === 'HEAD') return res.end();
      const file = fs.createReadStream(filePath, { start, end });
      file.pipe(res);
    } else {
      const head = {
        'Accept-Ranges': 'bytes',
        'Content-Length': fileSize,
        'Content-Type': contentType,
      };
      res.writeHead(200, head);
      if (req.method === 'HEAD') return res.end();
      fs.createReadStream(filePath).pipe(res);
    }
    return;
  }

  // --- Static Files Serving ---
  let filePath = path.join(PUBLIC_DIR, pathname === '/' ? 'index.html' : pathname);
  
  if (!filePath.startsWith(PUBLIC_DIR)) {
    res.writeHead(403);
    return res.end('Forbidden');
  }

  fs.stat(filePath, (err, stats) => {
    if (err || !stats.isFile()) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('404 Not Found');
      return;
    }

    const ext = path.extname(filePath).toLowerCase();
    const contentType = MIME_TYPES[ext] || 'application/octet-stream';

    res.writeHead(200, { 'Content-Type': contentType });
    fs.createReadStream(filePath).pipe(res);
  });
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`====================================================`);
  console.log(`🚀 OmniDownloader servidor listo en http://localhost:${PORT}`);
  console.log(`📁 Carpeta de descargas Omni: ${DOWNLOADS_DIR}`);
  console.log(`💻 Carpeta Descargas Windows: ${USER_DOWNLOADS_DIR}`);
  console.log(`====================================================`);
});
